#ifndef __STATS_H
#define __STATS_H
#include <iostream>
#include "Debug.h"
using namespace std;

enum PIPESTAGE { IF1 = 0, IF2 = 1, ID = 2, EXE1 = 3, EXE2 = 4, MEM1 = 5, 
                 MEM2 = 6, WB = 7, PIPESTAGES = 8 };

class Stats {
  private:
    long long cycles;
    int flushes;
    int bubbles;

    int memops;
    int branches;
    int taken;

    int hazRawExe1;
    int hazRawExe2;
    int hazRawMem1;
    int hazRawMem2;
    int hazRawTotal;

    int resultReg[PIPESTAGES];
    int resultStage[PIPESTAGES];

  public:
    Stats();

    void clock();

    void flush(int count);

    void registerSrc(int r, PIPESTAGE needed);
    void registerDest(int r, PIPESTAGE valid);

    void countMemOp() { memops++; }
    void countBranch() { branches++; }
    void countTaken() { taken++; }

    // getters
    long long getCycles() { return cycles; }
    int getFlushes() { return flushes; }
    int getBubbles() { return bubbles; }
    int getMemOps() { return memops; }
    int getBranches() { return branches; }
    int getTaken() { return taken; }

    int getHazRawExe1() { return hazRawExe1; }
    int getHazRawExe2() { return hazRawExe2; }
    int getHazRawMem1() { return hazRawMem1; }
    int getHazRawMem2() { return hazRawMem2; }
    int getHazRawTotal() { return hazRawTotal; }

  private:
    void bubble();
};

#endif
