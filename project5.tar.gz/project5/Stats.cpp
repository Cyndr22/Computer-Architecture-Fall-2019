/******************************
 * Submitted by: Connor Steed - crs268
 * CS 3339 - Fall 2019, Texas State University
 * Project 3 Pipelining
 * Copyright 2019, all rights reserved
 * Updated by Lee B. Hinkle based on prior work by Martin Burtscher and Molly O'Neil
 ******************************/
 
#include "Stats.h"

Stats::Stats() {
   cycles = PIPESTAGES - 1; // pipeline startup cost
   flushes = 0;
   bubbles = 0;
   stalls = 0;

   memops = 0;
   branches = 0;
   taken = 0;

   hazRawExe1 = 0;
   hazRawExe2 = 0;
   hazRawMem1 = 0;
   hazRawMem2 = 0;
   hazRawTotal = 0;

   for(int i = IF1; i < PIPESTAGES; i++) {
       resultReg[i] = -1;
       resultStage[i] = -1;
   }
}

void Stats::clock() {
   cycles++;

   // advance all pipeline flip-flops
   for(int i = WB; i > IF1; i--) {
       resultReg[i] = resultReg[i-1];
       resultStage[i] = resultStage[i-1];
   }
   // inject a no-op into IF1
   resultReg[IF1] = -1;
   resultStage[IF1] = -1;
}

void Stats::registerSrc(int r, PIPESTAGE needed) {
    for (int i = EXE1; i < WB; i++) {
        if (r == resultReg[i]) {
            hazRawTotal++;

            switch(i) {
                case EXE1:
                    hazRawExe1++;
                    break;
                case EXE2:
                    hazRawExe2++;
                    break;
                case MEM1:
                    hazRawMem1++;
                    break;
                case MEM2:
                    hazRawMem2++;
                    break;
                default:
                    break;
            }

            int valid = resultStage[i] - i;
            int avail = needed - ID;
            int bubbleCount = valid - avail;

            for (int j = 0; j < bubbleCount; j++) {
                bubble();
            }

            break;
        }
    }
}

void Stats::registerDest(int r, PIPESTAGE valid) {
    resultReg[ID] = r;
    resultStage[ID] = valid;
}

void Stats::flush(int count) { // count == how many ops to flush

    // advance all pipeline flip-flops
    for(int i = 0; i < count; i++) {
        for(int i = WB; i > IF1; i--) {
            resultReg[i] = resultReg[i-1];
            resultStage[i] = resultStage[i-1];
        }
        cycles++;
        flushes++;
    }
}

void Stats::stall(int count) {
    cycles += count;
    stalls += count;
}

void Stats::bubble() {
    cycles++;
    bubbles++;

    // advance all pipeline after ID
    for(int i = WB; i > ID; i--) {
        resultReg[i] = resultReg[i-1];
        resultStage[i] = resultStage[i-1];
    }
    resultReg[EXE1] = -1;
    resultStage[EXE1] = -1;
}
