/******************************
 * Submitted by: Connor Steed - crs268
 * CS 3339 - Fall 2019, Texas State University
 * Project 5 Data Cache
 * Copyright 2019, all rights reserved
 * Updated by Lee B. Hinkle based on prior work by Martin Burtscher and Molly O'Neil
 ******************************/
#include <iostream>
#include <cstdlib>
#include <iomanip>
#include "CacheStats.h"
using namespace std;

CacheStats::CacheStats() {
  cout << "Cache Config: ";
  if(!CACHE_EN) {
    cout << "cache disabled" << endl;
  } else {
    cout << (SETS * WAYS * BLOCKSIZE) << " B (";
    cout << BLOCKSIZE << " bytes/block, " << SETS << " sets, " << WAYS << " ways)" << endl;
    cout << "  Latencies: Lookup = " << LOOKUP_LATENCY << " cycles, ";
    cout << "Read = " << READ_LATENCY << " cycles, ";
    cout << "Write = " << WRITE_LATENCY << " cycles" << endl;
  }

  loads = 0;
  stores = 0;
  load_misses = 0;
  store_misses = 0;
  writebacks = 0;

  /* TODO: your code here */
  for (int i = 0; i < SETS; i++) {
      for (int j = 0; j < WAYS; j++) {
          modifiedBits[i][j] = false;
          validBits[i][j] = false;
          tags[i][j] = 0x00;
      }
      nextWay[i] = 0;
  }
}

int CacheStats::access(uint32_t addr, ACCESS_TYPE type) {
  if(!CACHE_EN) { // cache disabled
    return (type == LOAD) ? READ_LATENCY : WRITE_LATENCY;
  }

  /* TODO: your code here */
  int latency = 0;

  int way = 0;
  int set;
  uint32_t info = (addr >> 5); //throwing away data
  uint32_t index = (info & 0x07); //isolate the index bits
  uint32_t tag = (info >> 3); //throw out the index bits to isolate the tag bits

  bool hit = false;

  switch(index) {
      case 00:
          set = 0;
          break;
      case 0x01:
          set = 1;
          break;
      case 0x02:
          set = 2;
          break;
      case 0x03:
          set = 3;
          break;
      default:
          break;
  }

  way = nextWay[set];

  int num = 0;

  while (num < WAYS && !hit) {
      if (tags[set][num] == tag) {
          hit = true;
      } else {
          num++;
      }
  }

  if (hit) { //is it a hit? then no latency
      if(type == LOAD) { //lookup data
          loads++;
          return 0;
      } else { //hit the cache
          stores++;
          modifiedBits[set][way] = true;
          return 0;
      }
  } else { //it's a miss
      tags[set][way] = tag;

      if (nextWay[set] >= (WAYS - 1)) {
          nextWay[set] = 0;
      } else {
          nextWay[set]++;
      }

      if(type == LOAD) { //read miss
          loads++;
          load_misses++;
          if (modifiedBits[set][way] == 0) { //clean
              validBits[set][way] = true;
              return READ_LATENCY;
          } else { //dirty
              writebacks++;
              modifiedBits[set][way] = false;
              return READ_LATENCY + WRITE_LATENCY;
          }
      } else { //store miss
          stores++;
          store_misses++;
          if (modifiedBits[set][way] == 0) { //clean
              modifiedBits[set][way] = true;
              validBits[set][way] = true;
              return READ_LATENCY + WRITE_LATENCY;
          } else { //dirty
              writebacks++;
              return READ_LATENCY + WRITE_LATENCY;
          }
      }
  }

  return latency;
}

void CacheStats::printFinalStats() {
  /* TODO: your code here (don't forget to drain the cache of writebacks) */
  int drained = 0;

  for (int i = 0; i < SETS; i++) {
      for (int j = 0; j < WAYS; j++) {
          if (modifiedBits[i][j] == true) {
              drained++;
              modifiedBits[i][j] = false;
          }
      }
  }

  writebacks -= drained;

  int accesses = loads + stores;
  int misses = load_misses + store_misses;
  cout << "Accesses: " << accesses << endl;
  cout << "  Loads: " << loads << endl;
  cout << "  Stores: " << stores << endl;
  cout << "Misses: " << misses << endl;
  cout << "  Load misses: " << load_misses << endl;
  cout << "  Store misses: " << store_misses << endl;
  cout << "Writebacks: " << writebacks << endl;
  cout << "Hit Ratio: " << fixed << setprecision(1) << 100.0 * (accesses - misses) / accesses;
  cout << "%" << endl;
}
